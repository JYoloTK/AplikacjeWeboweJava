package rpg.course.potwor;

import java.io.IOException;
import java.io.Serializable;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import rpg.course.dao.PotworDAO;
import rpg.course.entities.Potwor;

@Named
@ViewScoped
public class PotworEditBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_POTWOR_LIST = "potworList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private Potwor potwor = new Potwor();
	private Potwor loaded = null;

	@EJB
	PotworDAO potworDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public Potwor getPotwor() {
		return potwor;
	}

	public void onLoad() throws IOException {
		// 1. load person passed through session
		// HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		// loaded = (Person) session.getAttribute("person");

		// 2. load person passed through flash
		loaded = (Potwor) flash.get("potwor");

		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			potwor = loaded;
			// session.removeAttribute("person");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		}

	}

	public String saveData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (potwor.getIdpotwor() == null) {
				// new record
				potworDAO.create(potwor);
			} else {
				// existing record
				potworDAO.merge(potwor);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_POTWOR_LIST;
	}
}
