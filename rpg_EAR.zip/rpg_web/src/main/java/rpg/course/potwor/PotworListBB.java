package rpg.course.potwor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import rpg.course.dao.PotworDAO;
import rpg.course.entities.Potwor;

@Named
@RequestScoped
public class PotworListBB {
	private static final String PAGE_POTWOR_EDIT = "potworEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String rasa;
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	PotworDAO potworDAO;
		
	public String getRasa() {
		return rasa;
	}

	public void setRasa(String rasa) {
		this.rasa = rasa;
	}

	public List<Potwor> getFullList(){
		return potworDAO.getFullList();
	}

	public List<Potwor> getList(){
		List<Potwor> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (rasa != null && rasa.length() > 0){
			searchParams.put("rasa", rasa);
		}
		
		//2. Get list
		list = potworDAO.getList(searchParams);
		
		return list;
	}

	public String newPotwor(){
		Potwor potwor = new Potwor();
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		flash.put("potwor", potwor);
		
		return PAGE_POTWOR_EDIT;
	}

	public String editPotwor(Potwor potwor){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("potwor", potwor);
		
		return PAGE_POTWOR_EDIT;
	}

	public String deletePotwor(Potwor potwor){
		potworDAO.remove(potwor);
		return PAGE_STAY_AT_THE_SAME;
	}
	
}
