package rpg.course.postac;

import java.io.IOException;
import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import rpg.course.dao.PostacDAO;
import rpg.course.entities.Postac;

@Named
@ViewScoped
public class PostacEditBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_POSTAC_LIST = "postacList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private Postac postac = new Postac();
	private Postac loaded = null;

	@EJB
	PostacDAO postacDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public Postac getPostac() {
		return postac;
	}

	public void onLoad() throws IOException {
		// 1. load person passed through session
		// HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		// loaded = (Person) session.getAttribute("person");

		// 2. load person passed through flash
		loaded = (Postac) flash.get("postac");

		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			postac = loaded;
			// session.removeAttribute("person");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		}

	}

	public String saveData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (postac.getIdpostac() == null) {
				// new record
				postacDAO.create(postac);
			} else {
				// existing record
				postacDAO.merge(postac);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_POSTAC_LIST;
	}
}
