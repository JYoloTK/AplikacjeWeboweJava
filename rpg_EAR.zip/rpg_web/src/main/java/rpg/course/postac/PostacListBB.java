package rpg.course.postac;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import rpg.course.dao.PostacDAO;
import rpg.course.entities.Postac;

@Named
@RequestScoped
public class PostacListBB {
	private static final String PAGE_POSTAC_EDIT = "postacEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String nazwa;
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	PostacDAO postacDAO;
		
	public String getNazwa() {
		return nazwa;
	}

	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}

	public List<Postac> getFullList(){
		return postacDAO.getFullList();
	}

	public List<Postac> getList(){
		List<Postac> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (nazwa != null && nazwa.length() > 0){
			searchParams.put("nazwa", nazwa);
		}
		
		//2. Get list
		list = postacDAO.getList(searchParams);
		
		return list;
	}

	public String newPostac(){
		Postac postac = new Postac();
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		flash.put("postac", postac);
		
		return PAGE_POSTAC_EDIT;
	}

	public String editPostac(Postac postac){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("postac", postac);
		
		return PAGE_POSTAC_EDIT;
	}

	public String deletePostac(Postac postac){
		postacDAO.remove(postac);
		return PAGE_STAY_AT_THE_SAME;
	}

}
