package rpg.course.lokacja;

import java.io.IOException;
import java.io.Serializable;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import rpg.course.dao.LokacjaDAO;
import rpg.course.entities.Lokacja;

@Named
@ViewScoped
public class LokacjaEditBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_LOKACJA_LIST = "lokacjaList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private Lokacja lokacja = new Lokacja();
	private Lokacja loaded = null;

	@EJB
	LokacjaDAO lokacjaDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public Lokacja getLokacja() {
		return lokacja;
	}

	public void onLoad() throws IOException {
		// 1. load person passed through session
		// HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		// loaded = (Person) session.getAttribute("person");

		// 2. load person passed through flash
		loaded = (Lokacja) flash.get("lokacja");

		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			lokacja = loaded;
			// session.removeAttribute("person");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		}

	}

	public String saveData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (lokacja.getIdlokacja() == null) {
				// new record
				lokacjaDAO.create(lokacja);
			} else {
				// existing record
				lokacjaDAO.merge(lokacja);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_LOKACJA_LIST;
	}
}
