package rpg.course.lokacja;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import rpg.course.dao.LokacjaDAO;
import rpg.course.entities.Lokacja;

@Named
@RequestScoped
public class LokacjaListBB {
	private static final String PAGE_LOKACJA_EDIT = "lokacjaEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String nazwalokacja;
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	LokacjaDAO lokacjaDAO;
		
	public String getNazwalokacja() {
		return nazwalokacja;
	}

	public void setNazwalokacja(String nazwalokacja) {
		this.nazwalokacja = nazwalokacja;
	}

	public List<Lokacja> getFullList(){
		return lokacjaDAO.getFullList();
	}

	public List<Lokacja> getList(){
		List<Lokacja> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (nazwalokacja != null && nazwalokacja.length() > 0){
			searchParams.put("nazwalokacja", nazwalokacja);
		}
		
		//2. Get list
		list = lokacjaDAO.getList(searchParams);
		
		return list;
	}

	public String newLokacja(){
		Lokacja lokacja = new Lokacja();
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		flash.put("lokacja", lokacja);
		
		return PAGE_LOKACJA_EDIT;
	}

	public String editLokacja(Lokacja lokacja){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("lokacja", lokacja);
		
		return PAGE_LOKACJA_EDIT;
	}

	public String deleteLokacja(Lokacja lokacja){
		lokacjaDAO.remove(lokacja);
		return PAGE_STAY_AT_THE_SAME;
	}
	
}
