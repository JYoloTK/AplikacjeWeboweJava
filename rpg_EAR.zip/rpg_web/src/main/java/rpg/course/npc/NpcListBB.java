package rpg.course.npc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import rpg.course.dao.NpcDAO;
import rpg.course.entities.Npc;

@Named
@RequestScoped
public class NpcListBB {
	private static final String PAGE_NPC_EDIT = "npcEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String nazwa;
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	NpcDAO npcDAO;
		
	public String getNazwa() {
		return nazwa;
	}

	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}

	public List<Npc> getFullList(){
		return npcDAO.getFullList();
	}

	public List<Npc> getList(){
		List<Npc> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (nazwa != null && nazwa.length() > 0){
			searchParams.put("nazwa", nazwa);
		}
		
		//2. Get list
		list = npcDAO.getList(searchParams);
		
		return list;
	}

	public String newNpc(){
		Npc npc = new Npc();
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		flash.put("npc", npc);
		
		return PAGE_NPC_EDIT;
	}

	public String editNpc(Npc npc){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("npc", npc);
		
		return PAGE_NPC_EDIT;
	}

	public String deleteNpc(Npc npc){
		npcDAO.remove(npc);
		return PAGE_STAY_AT_THE_SAME;
	}
	
}
