package rpg.course.swiat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import rpg.course.dao.SwiatDAO;
import rpg.course.entities.Swiat;

@Named
@RequestScoped
public class SwiatListBB {
	private static final String PAGE_SWIAT_EDIT = "swiatEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String nazwaswiat;
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	SwiatDAO swiatDAO;
		
	public String getNazwaswiat() {
		return nazwaswiat;
	}

	public void setNazwaswiat(String nazwaswiat) {
		this.nazwaswiat = nazwaswiat;
	}

	public List<Swiat> getFullList(){
		return swiatDAO.getFullList();
	}

	public List<Swiat> getList(){
		List<Swiat> list = null;
		
		//1. Prepare search params
		Map<String,Object> searchParams = new HashMap<String, Object>();
		
		if (nazwaswiat != null && nazwaswiat.length() > 0){
			searchParams.put("nazwaswiat", nazwaswiat);
		}
		
		//2. Get list
		list = swiatDAO.getList(searchParams);
		
		return list;
	}

	public String newSwiat(){
		Swiat swiat = new Swiat();
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash	
		flash.put("swiat", swiat);
		
		return PAGE_SWIAT_EDIT;
	}

	public String editSwiat(Swiat swiat){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("person", person);
		
		//2. Pass object through flash 
		flash.put("swiat", swiat);
		
		return PAGE_SWIAT_EDIT;
	}

	public String deleteSwiat(Swiat swiat){
		swiatDAO.remove(swiat);
		return PAGE_STAY_AT_THE_SAME;
	}
	
}
