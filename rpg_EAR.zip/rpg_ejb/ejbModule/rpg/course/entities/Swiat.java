package rpg.course.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the swiat database table.
 * 
 */
@Entity
@NamedQuery(name="Swiat.findAll", query="SELECT s FROM Swiat s")
public class Swiat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idswiat;

	private String nazwaswiat;

	private String setting;

	//bi-directional many-to-one association to Lokacja
	@OneToMany(mappedBy="swiat")
	private List<Lokacja> lokacjas;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="iduser")
	private User user;

	public Swiat() {
	}

	public Integer getIdswiat() {
		return this.idswiat;
	}

	public void setIdswiat(Integer idswiat) {
		this.idswiat = idswiat;
	}

	public String getNazwaswiat() {
		return this.nazwaswiat;
	}

	public void setNazwaswiat(String nazwaswiat) {
		this.nazwaswiat = nazwaswiat;
	}

	public String getSetting() {
		return this.setting;
	}

	public void setSetting(String setting) {
		this.setting = setting;
	}

	public List<Lokacja> getLokacjas() {
		return this.lokacjas;
	}

	public void setLokacjas(List<Lokacja> lokacjas) {
		this.lokacjas = lokacjas;
	}

	public Lokacja addLokacja(Lokacja lokacja) {
		getLokacjas().add(lokacja);
		lokacja.setSwiat(this);

		return lokacja;
	}

	public Lokacja removeLokacja(Lokacja lokacja) {
		getLokacjas().remove(lokacja);
		lokacja.setSwiat(null);

		return lokacja;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}