package rpg.course.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@NamedQuery(name="User.findAll", query="SELECT p FROM User p")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer iduser;

	private String haslo;

	private String login;

	private String rola;

	//bi-directional many-to-one association to Postac
	@OneToMany(mappedBy="user")
	private List<Postac> postacs;

	//bi-directional many-to-one association to Swiat
	@OneToMany(mappedBy="user")
	private List<Swiat> swiats;

	public User() {
	}

	public Integer getIduser() {
		return this.iduser;
	}

	public void setIduser(Integer iduser) {
		this.iduser = iduser;
	}

	public String getHaslo() {
		return this.haslo;
	}

	public void setHaslo(String haslo) {
		this.haslo = haslo;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getRola() {
		return this.rola;
	}

	public void setRola(String rola) {
		this.rola = rola;
	}

	public List<Postac> getPostacs() {
		return this.postacs;
	}

	public void setPostacs(List<Postac> postacs) {
		this.postacs = postacs;
	}

	public Postac addPostac(Postac postac) {
		getPostacs().add(postac);
		postac.setUser(this);

		return postac;
	}

	public Postac removePostac(Postac postac) {
		getPostacs().remove(postac);
		postac.setUser(null);

		return postac;
	}

	public List<Swiat> getSwiats() {
		return this.swiats;
	}

	public void setSwiats(List<Swiat> swiats) {
		this.swiats = swiats;
	}

	public Swiat addSwiat(Swiat swiat) {
		getSwiats().add(swiat);
		swiat.setUser(this);

		return swiat;
	}

	public Swiat removeSwiat(Swiat swiat) {
		getSwiats().remove(swiat);
		swiat.setUser(null);

		return swiat;
	}

}