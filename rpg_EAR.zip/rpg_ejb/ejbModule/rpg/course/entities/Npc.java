package rpg.course.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the npc database table.
 * 
 */
@Entity
@NamedQuery(name="Npc.findAll", query="SELECT n FROM Npc n")
public class Npc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idnpc;

	private String nazwa;

	private String rasa;

	//bi-directional many-to-one association to Lokacja
	@ManyToOne
	@JoinColumn(name="idlokacja")
	private Lokacja lokacja;

	public Npc() {
	}

	public Integer getIdnpc() {
		return this.idnpc;
	}

	public void setIdnpc(Integer idnpc) {
		this.idnpc = idnpc;
	}

	public String getNazwa() {
		return this.nazwa;
	}

	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}

	public String getRasa() {
		return this.rasa;
	}

	public void setRasa(String rasa) {
		this.rasa = rasa;
	}

	public Lokacja getLokacja() {
		return this.lokacja;
	}

	public void setLokacja(Lokacja lokacja) {
		this.lokacja = lokacja;
	}

}