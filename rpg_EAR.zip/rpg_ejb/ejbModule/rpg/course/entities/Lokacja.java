package rpg.course.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the lokacja database table.
 * 
 */
@Entity
@NamedQuery(name="Lokacja.findAll", query="SELECT l FROM Lokacja l")
public class Lokacja implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idlokacja;

	private String biom;

	private String nazwalokacja;

	private String wielkosc;

	//bi-directional many-to-one association to Swiat
	@ManyToOne
	@JoinColumn(name="idswiat")
	private Swiat swiat;

	//bi-directional many-to-one association to Npc
	@OneToMany(mappedBy="lokacja")
	private List<Npc> npcs;

	//bi-directional many-to-one association to Potwor
	@OneToMany(mappedBy="lokacja")
	private List<Potwor> potwors;

	public Lokacja() {
	}

	public Integer getIdlokacja() {
		return this.idlokacja;
	}

	public void setIdlokacja(Integer idlokacja) {
		this.idlokacja = idlokacja;
	}

	public String getBiom() {
		return this.biom;
	}

	public void setBiom(String biom) {
		this.biom = biom;
	}

	public String getNazwalokacja() {
		return this.nazwalokacja;
	}

	public void setNazwalokacja(String nazwalokacja) {
		this.nazwalokacja = nazwalokacja;
	}

	public String getWielkosc() {
		return this.wielkosc;
	}

	public void setWielkosc(String wielkosc) {
		this.wielkosc = wielkosc;
	}

	public Swiat getSwiat() {
		return this.swiat;
	}

	public void setSwiat(Swiat swiat) {
		this.swiat = swiat;
	}

	public List<Npc> getNpcs() {
		return this.npcs;
	}

	public void setNpcs(List<Npc> npcs) {
		this.npcs = npcs;
	}

	public Npc addNpc(Npc npc) {
		getNpcs().add(npc);
		npc.setLokacja(this);

		return npc;
	}

	public Npc removeNpc(Npc npc) {
		getNpcs().remove(npc);
		npc.setLokacja(null);

		return npc;
	}

	public List<Potwor> getPotwors() {
		return this.potwors;
	}

	public void setPotwors(List<Potwor> potwors) {
		this.potwors = potwors;
	}

	public Potwor addPotwor(Potwor potwor) {
		getPotwors().add(potwor);
		potwor.setLokacja(this);

		return potwor;
	}

	public Potwor removePotwor(Potwor potwor) {
		getPotwors().remove(potwor);
		potwor.setLokacja(null);

		return potwor;
	}

}