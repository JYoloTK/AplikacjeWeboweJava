package rpg.course.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the postac database table.
 * 
 */
@Entity
@NamedQuery(name="Postac.findAll", query="SELECT p FROM Postac p")
public class Postac implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idpostac;

	private String klasa;

	private String level;

	private String nazwa;

	private String rasa;

	private String wiek;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="iduser")
	private User user;

	public Postac() {
	}

	public Integer getIdpostac() {
		return this.idpostac;
	}

	public void setIdpostac(Integer idpostac) {
		this.idpostac = idpostac;
	}

	public String getKlasa() {
		return this.klasa;
	}

	public void setKlasa(String klasa) {
		this.klasa = klasa;
	}

	public String getLevel() {
		return this.level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getNazwa() {
		return this.nazwa;
	}

	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}

	public String getRasa() {
		return this.rasa;
	}

	public void setRasa(String rasa) {
		this.rasa = rasa;
	}

	public String getWiek() {
		return this.wiek;
	}

	public void setWiek(String wiek) {
		this.wiek = wiek;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}