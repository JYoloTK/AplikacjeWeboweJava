package rpg.course.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the potwor database table.
 * 
 */
@Entity
@NamedQuery(name="Potwor.findAll", query="SELECT p FROM Potwor p")
public class Potwor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer idpotwor;

	private Integer ac;

	private Integer cr;

	private Integer hp;

	private String rasa;

	private Integer speed;

	//bi-directional many-to-one association to Lokacja
	@ManyToOne
	@JoinColumn(name="idlokacja")
	private Lokacja lokacja;

	public Potwor() {
	}

	public Integer getIdpotwor() {
		return this.idpotwor;
	}

	public void setIdpotwor(Integer idpotwor) {
		this.idpotwor = idpotwor;
	}

	public Integer getAc() {
		return this.ac;
	}

	public void setAc(Integer ac) {
		this.ac = ac;
	}

	public Integer getCr() {
		return this.cr;
	}

	public void setCr(Integer cr) {
		this.cr = cr;
	}

	public Integer getHp() {
		return this.hp;
	}

	public void setHp(Integer hp) {
		this.hp = hp;
	}

	public String getRasa() {
		return this.rasa;
	}

	public void setRasa(String rasa) {
		this.rasa = rasa;
	}

	public Integer getSpeed() {
		return this.speed;
	}

	public void setSpeed(Integer speed) {
		this.speed = speed;
	}

	public Lokacja getLokacja() {
		return this.lokacja;
	}

	public void setLokacja(Lokacja lokacja) {
		this.lokacja = lokacja;
	}

}