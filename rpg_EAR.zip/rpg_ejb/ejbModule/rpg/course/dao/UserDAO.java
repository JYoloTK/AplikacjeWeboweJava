package rpg.course.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import rpg.course.entities.User;

@Stateless
public class UserDAO {

	private final static String UNIT_NAME = "jsfcourse-rpgPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	EntityManager em;
	
	public void create(User user) {
		em.persist(user);
	}

	public User merge(User user) {
		return em.merge(user);
	}

	public void remove(User user) {
		em.remove(em.merge(user));
	}

	public User find(Object iduser) {
		return em.find(User.class, iduser);
	}
	
	public List<User> getFullList() {
		List<User> list = null;

		Query query = em.createQuery("select p from User p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<User> getList(Map<String, Object> searchParams) {
		List<User> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from User p ";
		String where = "";
		String orderby = "order by p.login asc, p.haslo";

		// search for surname
		String login = (String) searchParams.get("login");
		if (login != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.login like :login ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (login != null) {
			query.setParameter("login", login+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	// simulate finding user in DB
	public User getUserFromDatabase(String login, String haslo) {
		
		User u;
		
		String select = "select p ";
		String from = "from User p ";
		String where = "";

		// search for surname
		if (login != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.login like :login ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		if (login != null) {
			query.setParameter("login", login+"%");
		}
		
		u = new User();
		u.setLogin(login);
		u.setHaslo(haslo);
		
//		String select = "select p from User p where p.login like :login and p.haslo like :haslo";
//		Query query = em.createQuery(select);
//		u = query.;
		
//		if (login.equals("admin") && haslo.equals("admin")) {
//			u = new User();
//			u.setLogin(login);
//			u.setHaslo(haslo);
//		}

		return u;
	}

}
