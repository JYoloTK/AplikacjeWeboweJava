package rpg.course.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import rpg.course.entities.Potwor;

@Stateless
public class PotworDAO {

	private final static String UNIT_NAME = "jsfcourse-rpgPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	EntityManager em;
	
	public void create(Potwor potwor) {
		em.persist(potwor);
	}

	public Potwor merge(Potwor potwor) {
		return em.merge(potwor);
	}

	public void remove(Potwor potwor) {
		em.remove(em.merge(potwor));
	}

	public Potwor find(Object idpotwor) {
		return em.find(Potwor.class, idpotwor);
	}
	
	public List<Potwor> getFullList() {
		List<Potwor> list = null;

		Query query = em.createQuery("select p from Potwor p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Potwor> getList(Map<String, Object> searchParams) {
		List<Potwor> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Potwor p ";
		String where = "";
		String orderby = "order by p.rasa asc, p.cr";

		// search for surname
		String rasa = (String) searchParams.get("rasa");
		if (rasa != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.nazwa like :nazwa ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (rasa != null) {
			query.setParameter("rasa", rasa+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
