package rpg.course.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import rpg.course.entities.Swiat;

@Stateless
public class SwiatDAO {

	private final static String UNIT_NAME = "jsfcourse-rpgPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	EntityManager em;
	
	public void create(Swiat swiat) {
		em.persist(swiat);
	}

	public Swiat merge(Swiat swiat) {
		return em.merge(swiat);
	}

	public void remove(Swiat swiat) {
		em.remove(em.merge(swiat));
	}

	public Swiat find(Object idswiat) {
		return em.find(Swiat.class, idswiat);
	}
	
	public List<Swiat> getFullList() {
		List<Swiat> list = null;

		Query query = em.createQuery("select p from Swiat p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Swiat> getList(Map<String, Object> searchParams) {
		List<Swiat> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Swiat p ";
		String where = "";
		String orderby = "order by p.nazwaswiat asc, p.setting";

		// search for surname
		String nazwaswiat = (String) searchParams.get("nazwaswiat");
		if (nazwaswiat != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.nazwaswiat like :nazwaswiat ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (nazwaswiat != null) {
			query.setParameter("nazwaswiat", nazwaswiat+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
