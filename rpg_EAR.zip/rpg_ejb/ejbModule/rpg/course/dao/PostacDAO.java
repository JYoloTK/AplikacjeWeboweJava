package rpg.course.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import rpg.course.entities.Postac;

@Stateless
public class PostacDAO {

	private final static String UNIT_NAME = "jsfcourse-rpgPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	EntityManager em;
	
	public void create(Postac postac) {
		em.persist(postac);
	}

	public Postac merge(Postac postac) {
		return em.merge(postac);
	}

	public void remove(Postac postac) {
		em.remove(em.merge(postac));
	}

	public Postac find(Object idpostac) {
		return em.find(Postac.class, idpostac);
	}
	
	public List<Postac> getFullList() {
		List<Postac> list = null;

		Query query = em.createQuery("select p from Postac p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Postac> getList(Map<String, Object> searchParams) {
		List<Postac> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Postac p ";
		String where = "";
		String orderby = "order by p.nazwa asc, p.klasa";

		// search for surname
		String nazwa = (String) searchParams.get("nazwa");
		if (nazwa != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.nazwa like :nazwa ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (nazwa != null) {
			query.setParameter("nazwa", nazwa+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
