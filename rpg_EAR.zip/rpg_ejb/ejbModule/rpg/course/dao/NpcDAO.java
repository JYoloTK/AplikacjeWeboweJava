package rpg.course.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import rpg.course.entities.Npc;

@Stateless
public class NpcDAO {

	private final static String UNIT_NAME = "jsfcourse-rpgPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	EntityManager em;
	
	public void create(Npc npc) {
		em.persist(npc);
	}

	public Npc merge(Npc npc) {
		return em.merge(npc);
	}

	public void remove(Npc npc) {
		em.remove(em.merge(npc));
	}

	public Npc find(Object idnpc) {
		return em.find(Npc.class, idnpc);
	}
	
	public List<Npc> getFullList() {
		List<Npc> list = null;

		Query query = em.createQuery("select p from Npc p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Npc> getList(Map<String, Object> searchParams) {
		List<Npc> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Npc p ";
		String where = "";
		String orderby = "order by p.nazwa asc, p.rasa";

		// search for surname
		String nazwa = (String) searchParams.get("nazwa");
		if (nazwa != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.nazwa like :nazwa ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (nazwa != null) {
			query.setParameter("nazwa", nazwa+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
