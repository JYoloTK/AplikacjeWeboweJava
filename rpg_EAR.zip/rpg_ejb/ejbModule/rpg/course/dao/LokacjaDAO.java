package rpg.course.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import rpg.course.entities.Lokacja;

@Stateless
public class LokacjaDAO {

	private final static String UNIT_NAME = "jsfcourse-rpgPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	EntityManager em;
	
	public void create(Lokacja lokacja) {
		em.persist(lokacja);
	}

	public Lokacja merge(Lokacja lokacja) {
		return em.merge(lokacja);
	}

	public void remove(Lokacja lokacja) {
		em.remove(em.merge(lokacja));
	}

	public Lokacja find(Object idlokacja) {
		return em.find(Lokacja.class, idlokacja);
	}
	
	public List<Lokacja> getFullList() {
		List<Lokacja> list = null;

		Query query = em.createQuery("select p from Lokacja p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Lokacja> getList(Map<String, Object> searchParams) {
		List<Lokacja> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Lokacja p ";
		String where = "";
		String orderby = "order by p.nazwalokacja asc, p.wielkosc";

		// search for surname
		String nazwalokacja = (String) searchParams.get("nazwalokacja");
		if (nazwalokacja != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.nazwalokacja like :nazwalokacja ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);

		// 3. Set configured parameters
		if (nazwalokacja != null) {
			query.setParameter("nazwalokacja", nazwalokacja+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
